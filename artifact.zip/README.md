# Templates and null-dereference results

This folder contains points-to templates and null-dereference results for six Java applications.

| Folder | Application |
| --- | --- |
| A1 | Sunflow |
| A2 | jsoup |
| A3 | Proton-J |
| A4 | GraphHopper |
| A5 | Xalan |
| A6 | Avrora |

Each application folder stores its JSON and XML templates in `templates/` and its analysis results in `Soot/`, `IBM WALA/`, and `Tai-e/`.

Each framework folder contains `native-null-dereference.csv` for native analysis and `template-null-dereference.csv` for template-aware analysis. Both files use the following columns:

```csv
SiteId,Method,LineNumber,Variable,Kind,PotentialNullDereference
```

Each row represents an examined dereference site. `True` means the detector flags the site; `False` means it does not. Blank fields indicate unavailable values. Use `SiteId` to compare the two files within the same application and framework. A missing site is unknown, not `False`.
